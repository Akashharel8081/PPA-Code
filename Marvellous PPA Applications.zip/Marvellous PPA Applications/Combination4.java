// Case 4
class Demo 
{
    int i;
    void fun()
    {}
}
class Hello
{
    int i;
    void fun()
    {}
}
class Marvellous extends Demo, Hello    // Error
{
}