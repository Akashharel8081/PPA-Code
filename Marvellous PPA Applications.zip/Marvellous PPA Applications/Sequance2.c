#include<stdio.h>

int main()
{
    int no1 = 10;
    int no2 = 11;

    printf("Addition is : %d",no1+no2);

    return 0;
}