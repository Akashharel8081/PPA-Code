class StringDemo2
{
    public static void main(String a[])
    {
        String s1 = "Hello";
        String s2 = new String("Demo");
        String s3 = "Hello";
        String s4 = new String("Demo");
        String s5 = new String("Ganesh");
        String s6 = "Marvellous";

        System.out.println("Length of s1 is"+s1.length());
    }
}