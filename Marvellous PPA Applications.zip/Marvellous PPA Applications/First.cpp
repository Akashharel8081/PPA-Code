#include<iostream>

using namespace std;

int main()
{
    cout<<"Jay Ganesh\n";

    return 0;
}

// g++ First.cpp -o Myexe

// Myexe            Windows
// ./Myexe          Linux

























