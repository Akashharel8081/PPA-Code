#include<iostream>
using namespace std;

int main()
{
    int no = 11;

    int &ref = no;

    int *p = &no;


    return 0;
}