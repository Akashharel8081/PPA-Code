#include<stdio.h>

struct Demo
{
    int A;
    int B;
};

#define PI 3.14

typedef int * IPTR;