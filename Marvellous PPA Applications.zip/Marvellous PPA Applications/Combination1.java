// Case 1
class Demo 
{
}

class Hello extends Demo
{
}