#include<stdio.h>

int main()
{
        printf("Marvellous Infosystems\n");


        return 0;
}