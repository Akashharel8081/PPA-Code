#include<stdio.h>

int No1 = 11;
int No2;

void Demo()
{
        printf("Inside Demo\n");
}