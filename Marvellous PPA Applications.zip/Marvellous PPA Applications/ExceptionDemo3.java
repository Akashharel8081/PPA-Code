import java.util.*;

class ExceptionDemo3
{
    public static void main(String a[])
    {
        String s1 = "Marvellous";
        String s2 = null;

        System.out.println("Data of s1 is : "+s1);
        System.out.println("Data of s2 is : "+s2);

        System.out.println("length of s1 is : "+s1.length());
        System.out.println("length of s2 is : "+s2.length());
    }
}