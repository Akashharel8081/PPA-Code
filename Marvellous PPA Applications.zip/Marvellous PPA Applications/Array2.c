#include<stdio.h>

int main()
{
    int Arr[4] = {10,20,30,40};

    printf("%d\n",Arr[0]);      // 10
    printf("%d\n",Arr[1]);      // 20

    return 0;
}