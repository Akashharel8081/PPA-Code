#include<stdio.h>

extern int No1;
extern int No2;

int main()
{
        printf("Value of No1 : %d\n",No1);
        printf("Value of No2 : %d\n",No2);
        
        return 0;
}