// Case 2
class Demo 
{
}
class Hello extends Demo
{
}
class Marvellous extends Hello
{
}