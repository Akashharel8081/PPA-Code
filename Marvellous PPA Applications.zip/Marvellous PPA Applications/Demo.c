#include<stdio.h>

int main()
{
    printf("Jay Ganesh...");

    return 0;
}