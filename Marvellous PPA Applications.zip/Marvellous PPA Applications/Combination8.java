// Case 8
interface Demo 
{
    void fun();
}
interface Hello extends Demo
{
    void gun();
}
class Marvellous implements Hello
{
    void fun()
    {}
    void gun()
    {}
}