// Case 5
interface Demo 
{
}
class Hello implements Demo
{
}
